// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("docstring coverage\n", stdout);
  return lionss_run_workload("docstring-coverage");
}
